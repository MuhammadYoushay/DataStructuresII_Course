import csv
from rbtree import RedBlackTree
from time import time

def test_sorted()->None:
    rows = []
    with open("SortedData.csv", 'r') as file:
        csvreader = csv.reader(file)
        for row in csvreader:
            rows.append(int(row[0]))
        bst = RedBlackTree()
        for i in rows:
            bst.insert(i)
    

times = []            
for i in range(10):
    initial= time()
    test_sorted()
    end= time()
    final = end - initial
    times.append(final)

sum = 0
for j in times:
    sum += j
average = sum/10
print(average)
