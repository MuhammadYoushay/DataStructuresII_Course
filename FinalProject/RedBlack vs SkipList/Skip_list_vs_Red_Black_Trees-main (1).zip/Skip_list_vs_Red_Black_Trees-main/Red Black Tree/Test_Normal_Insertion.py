from rbtree import RedBlackTree
def test_insert() -> None:
    bst = RedBlackTree()
    bst.insert(73)
    bst.insert(48)
    bst.insert(100)
    bst.insert(42)
    bst.insert(55)
    bst.insert(40)
    bst.insert(58)
    bst.insert(56)
    bst.print_tree()
test_insert()
