import csv
from rbtree import RedBlackTree
from time import time

def test_random()->None:
    rows = []
    with open("RandomData.csv", 'r') as file:
        csvreader = csv.reader(file)
        for row in csvreader:
            rows.append(int(row[0]))
        bst = RedBlackTree()
        for i in rows:
            bst.insert(i)
   
x = time()
test_random()
y = time()
print(y-x)