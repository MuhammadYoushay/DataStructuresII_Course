import csv
from rbtree import RedBlackTree
from time import time

def test_large()->None:
    rows = []
    with open("LargeData.csv", 'r') as file:
        csvreader = csv.reader(file)
        for row in csvreader:
            rows.append(int(row[0]))
        bst = RedBlackTree()
        for i in rows:
            bst.insert(i)
    
times = []            
for i in range(10):
    initial= time()
    test_large()
    end= time()
    final = end - initial
    times.append(final)

sum = 0
for j in times:
    sum += j
average = sum/10
print(average)