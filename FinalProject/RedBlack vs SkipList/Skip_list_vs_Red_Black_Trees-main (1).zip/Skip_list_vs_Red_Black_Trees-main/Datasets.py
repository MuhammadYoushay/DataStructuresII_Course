import random

# Define the size of the dataset
size = 100000

# Create a list of random integers
Random_Data = [random.randint(0, 1000) for i in range(size)]


#sorted dataset
# Create a list of sorted integers
Sorted_Data = [i for i in range(size)]


# Define the size of the dataset
LargeSize = 1000000 

# Create a list of random integers
Large_Data = [random.randint(0, 1000) for i in range(LargeSize)]


# creating files of datasets
with open('RandomData.csv','w') as f:
    for item in Random_Data:
        print(item, file=f)

with open('LargeData.csv','w') as f:
    for item in Large_Data:
        print(item, file=f)

with open('SortedData.csv','w') as f:
    for item in Sorted_Data:
        print(item, file=f)