from skiplist import SkipList
from time import time
import csv

def test_large()->None:
    rows = []
    with open("LargeData.csv", 'r') as file:
        csvreader = csv.reader(file)
        for row in csvreader:
            rows.append(int(row[0]))
        skip = SkipList(10, 0.5)
        for i in rows:
            skip.insertElement(i)

times = []            
for i in range(10):
    initial= time()
    test_large()
    end= time()
    final = intial - end
    times.append(final)

sum = 0
for j in times:
    sum += j
average = sum/10
print(average)    