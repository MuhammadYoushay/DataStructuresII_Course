from skiplist import SkipList

import csv
from time import time

def test_sorted()->None:
    rows = []
    with open("SortedData.csv", 'r') as file:
        csvreader = csv.reader(file)
        for row in csvreader:
            rows.append(int(row[0]))
        skip = SkipList(2, 0.5)
        for i in rows:
            skip.insertElement(i)

times = []            
for i in range(10):
    initial= time()
    test_sorted()
    end= time()
    final = intial - end
    times.append(final)

sum = 0
for j in times:
    sum += j
average = sum/10