from document import Document
class TrieNode:
    def __init__(self) -> None:
        
    
        self.finish=False #bool set to check if the traversal or word is completed
        self.child={}
        self.locate=[]#to check the occurnece in the current doc



class Trie:
    def __init__(self) -> None:
        self.empty_node=TrieNode() 

    def add_document(self,doc:Document)->None: #to get the words from the document
        for word in doc:
            point=self.insert(word) #to get the words out of the document inorder to be used in the tree
            lst=doc.terms[word] #start and end in tuple
            for wrd in lst:
                point.locate.append((doc.doc_id,wrd[0],wrd[1])) #docid,start, end of the term


    def insert(self,word:Document)-> TrieNode:
        point=self.empty_node #rootniode
        for letter in word:
            if letter not in point.child:
                node=TrieNode()
                point.child[letter]=node #key values are the letter against the values as nodes
                point=point.child[letter]
            else:
                point=point.child[letter] #so the letters can be repeated irresptove of different values ie children
        point.finish=True #the word is donee
        return point

    def dfs(self,word,point):
        if point.finish==True:
            self.result[word]=point.locate #inorder  to get all the occurences of the word as soon as it reaches end
        for i in point.child:
            self.dfs(word+i,point.child[i]) #recursively using dfs and traversing within children nodes for multiple cobinations of the word


    def prefix_complete(self,prefix:str): 
        self.result={}
        point=self.empty_node #a pointer to point to root node
        word=""
        for letter in prefix:
            if letter in point.child:
                word=word+letter #dfs is called and a path is made when each letter is added in the word
                point=point.child[letter]
            else:
                return self.result
        self.dfs(word,point)#the dictionary has the required tuple
        return self.result     
        


    
    

        









