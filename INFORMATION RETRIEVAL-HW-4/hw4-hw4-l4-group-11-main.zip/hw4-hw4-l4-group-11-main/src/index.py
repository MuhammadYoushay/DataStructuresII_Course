import math
from document import Document
from typing import List, Tuple

class InvertedIndex:
    def __init__(self, corpus: List[Document]):
        self.index = dict() #dictionary that maps terms to a list of document IDs
        self.doc_lengths = dict() #maps the document iD to the total number of occurences
        self.num_docs = len(corpus)#total number of documents 
        for doc in corpus: # Building the index, basically the table as explained in class by iterating through the document
            self.doc_lengths[doc.doc_id] = 0
            for term, positions in doc.terms.items():
                self.index.setdefault(term, dict())
                self.index[term][doc.doc_id] = len(positions)
                self.doc_lengths[doc.doc_id] = self.doc_lengths[doc.doc_id] + len(positions)
        self.idf = dict() #Computing the IDF for each term, help regarding this calculation taken from online resources 
        n = len(corpus)
        for term, docs in self.index.items():
            df = len(docs)
            self.idf[term] = math.log((n) / (df))

    def query(self, terms: str, k: int) -> List[Tuple[int, str]]: #Function created to deal with test cases having a single query
        query_terms = terms.split()
        scores = dict()
        result = []
        for doc_id in self.doc_lengths.keys(): #Calculating the score for each individual document
            doc_score = 0
            for term in query_terms:
                if term not in self.index:
                    continue
                tf = self.index[term].get(doc_id, 0)
                if self.doc_lengths[doc_id] == 0:
                    continue
                doc_score += (tf / self.doc_lengths[doc_id]) * self.idf[term]
            if doc_score != 0:
                scores[doc_id] = doc_score
        for i, doc_id in enumerate(sorted(scores, key=scores.get, reverse=True)): #Sorting the documents according to the score calculated previously, also ensuring top k results are fetched
            if i == k:
                break
            result.append((scores[doc_id], doc_id))
        return result

    def and_query(self, query1: str, query2: str, k: int) -> List[Tuple[int, str]]: #Function created to deal with test cases with two queries. We basically need the intersection between the two 
        results_query1 = self.query(query1, k)
        results_query2 = self.query(query2, k)
        intersection = []
        for i, doc_id1 in results_query1: #looping through query1
            for j, doc_id2 in results_query2: #looping through query2
                if doc_id1 == doc_id2: #if in both, append
                    intersection.append((i, doc_id1))
                    break
        n = len(intersection) #Sorting through bubble sort
        for i in range(n):
            for j in range(0, n-i-1):
                if intersection[j][1] > intersection[j+1][1]:
                    intersection[j], intersection[j+1] = intersection[j+1], intersection[j] 
        return intersection
    
    def or_query(self, query1: str, query2: str, k: int) -> List[Tuple[int, str]]: #Function created to deal with test cases with two queries. We basically need the union between the two 
        results_query1 = self.query(query1, k)
        results_query2 = self.query(query2, k)
        union = []
        for rank1, doc_id1 in results_query1: #looping for query1
            union.append((rank1, doc_id1))
        for rank2, doc_id2 in results_query2:
            found = False
            for rank1, doc_id1 in results_query1: #looping for query2
                if doc_id2 == doc_id1: #added this condition as some test cases were giving me errors. We had to break the loop if similar id found
                    found = True
                    break
            if not found:
                union.append((rank2, doc_id2))
        n = len(union) #Sorting through bubble sort
        for i in range(n):
            for j in range(0, n-i-1):
                if union[j][1] > union[j+1][1]:
                    union[j], union[j+1] = union[j+1], union[j]      
        return union



