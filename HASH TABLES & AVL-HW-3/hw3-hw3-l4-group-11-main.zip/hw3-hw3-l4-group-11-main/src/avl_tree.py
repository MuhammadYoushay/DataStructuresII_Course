from typing import Tuple
from typing import List


class AVLTreeNode:
    def __init__(self, key: str, value: Tuple[int,int]):
        self.key = key
        self.value = value
        self.left = None
        self.right = None
        self.height = 1
        
class AVLTree:
    def __init__(self):
        self.root = None
        
    def helper_insert(self, point, key, value):
        if point is None:
            return AVLTreeNode(key, value) #base case for inserting root the first time it always be None

        if key < point.key: #checking if the key is smaller than the node key then insertion to take place on left
            point.left = self.helper_insert(point.left, key, value)
        elif key > point.key:#checking if the key is bigger than the node key then insertion to take place on right
            point.right = self.helper_insert(point.right, key, value)
        else:
            point.value.append(value)
            self.recompute_height(point) #if not such cases then simply calculate the height and return thr node
            return point
        
        self.recompute_height(point) #it simply updates the height after the insertion as it increases by one

        height_difference = self.new_height(point.left) - self.new_height(point.right)#the differernce helps to balance the tree

        #if point.left is not None:
        if height_difference > 1 and key > point.left.key:#if it is unbalanced and the left is smaller than key the final right rotation is made  
            point.left = self.rotate_left(point.left)
            return self.rotate_right(point) #LR
        elif height_difference > 1 and key < point.left.key:
            return self.rotate_right(point) #LL

        #if point.right is not None:
        elif height_difference <- 1 and key < point.right.key:#if it is unbalanced and the right is bigger than key the final left rotation is made  
            point.right = self.rotate_right(point.right)
            return self.rotate_left(point) #RL
        elif height_difference < -1 and key > point.right.key:
            return self.rotate_left(point) #RR   
        return point

    def insert(self, key, value):
        self.root = self.helper_insert(self.root, key, value) #passes the value to the helper insert      

    def helper_search(self, root, key):
        if root is None:
            return None # for the first node
        if key == root.key:
            return root.value #returns the value if it finds the key
        elif key < root.key:
            return self.helper_search(root.left, key) #compares the value that if key is smaller then will search in left
        else:
            return self.helper_search(root.right, key)#else will search in right

    def search (self,key:str) -> List[Tuple[int,int] ] :
        result = self.helper_search(self.root, key) #passes the value to the helper search
        return result 
    
    def recompute_height(self, node):#so the height is recomputed based on the max height between the left and right node and then one is added in the max one     
        node.height = 1 + max(self.height(node.left), self.height(node.right))
               
    def new_height(self, node: AVLTreeNode) -> int:
        if not node:
            return 0
        else:
            return 1 + max(self.new_height(node.left), self.new_height(node.right))#helps to return the caluation of the new height after insertion to be called above

    def height(self,node:AVLTreeNode)-> None:
        if node == None:
            return 0
        else:
            return node.height #helps to return the height of the tree
    
    def rotate_left(self,point:AVLTreeNode)-> AVLTreeNode:
        rotated_point = point.right #first the rotation is made to bring the right node to parent and then that rotated point is adjusted to left
        point.right = rotated_point.left
        rotated_point.left = point #estabilsing the node finally
        self.recompute_height(point)
        return rotated_point

    def rotate_right(self,point:AVLTreeNode)-> AVLTreeNode:    
        rotated_point = point.left #first the rotation is made to bring the left node to parent and then that rotated point is adjusted to right
        point.left = rotated_point.right
        rotated_point.right = point#estabilishing the connections
        self.recompute_height(point)
        return rotated_point

    def helper_display(self, root, lst):#It helps in inorder traversal ie left ,root ,right
        if root == None:
            return
        self.helper_display(root.left, lst)
        lst.append([root.key, root.height])
        self.helper_display(root.right, lst)

    def display(self)-> List[str]:  # SYNTAX->(height, current node, left node, right node) 
        lst = []
        self.helper_display(self.root, lst)
        return lst

        

                                    

