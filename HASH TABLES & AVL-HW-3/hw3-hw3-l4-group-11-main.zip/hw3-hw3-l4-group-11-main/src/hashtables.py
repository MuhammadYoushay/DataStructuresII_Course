from typing import Any
import random

# The implementation of Hashing and Chainig in this code is greatly inspired by the pseudocode in the Open Data Structures (ODS) book.
# This implementation was taught in class as well.

class MySet(object):
    '''An abstract class that provides a set interface which is just sufficient
    for the implementation of this assignment.
    '''

    def __init__(self, elements: [Any]) -> None:
        """Initializes this set with elements.

        Each element in elements must be hashable by python.

        Args:
        - self: manadatory reference to this object.
        - elements: this set is populated with these elements.

        Returns:
        None
        """
        pass

    def add(self, element: Any) -> None:
        """Adds element to this set.

        element must be hashable by python.

        Args:
        - self: manadatory reference to this object.
        - element: the element to add to this set

        Returns:
        None
        """
        pass    

    def discard(self, element: Any) -> None:
        """Removes element from this set.

        there is noting to be done if element is not present in this set.

        Args:
        - self: manadatory reference to this object.
        - element: the element to remove from this set

        Returns:
        None
        """
        pass    

    def __iter__(self):
        """Makes this set iterable.

        There are many different ways to implement this. Choose one that works
        for you.

        Args:
        - self: manadatory reference to this object.
        """
        pass
    
class ChainedSet(MySet):
    '''Overrides and implementes the methods defined in MySet. Uses a chained
    hash table to implement the set.
    '''
    def __init__(self, elements: [Any]) -> None:
        self.size = 2 ** len(elements) #Setting the size of the hash table to the power of 2 of the length of the input list
        self.table = [[] for _ in range(self.size)] # Initializing an empty list for each bucket in the hash table
        self.load_factor = 0.75 # Setting the load factor to 0.75 took help from online resources to do this. My main objective was to increase the speed of the code. We rehash the table when this threshold is reached.
        self.n = 0 # Initializing the number of elements to 0
        self.mask = self.size - 1 # Set the mask to the size of the hash table minus 1, took help from online resources to do this. My main objective was to increase the speed of the code
        for element in elements: # Adding each element in the input list to the hash table
            self.add(element)

    def hash_function(self, x): #Used built in hash function. Here I took help from the book as well as online resources to implement the mask part
            return hash(x) & self.mask

    def add(self, element: Any): # This function first computes the index of the bucket using the hash function. If the element is already in the bucket, the function does nothing and returns False. Otherwise it adds the element to the bucket and increments the number of elements. If the load factor is exceeded the hash table is resized using the resize method.
        i = self.hash_function(element)
        bucket = self.table[i]
        if element in bucket:
            return False
        bucket.append(element)
        self.n += 1
        if self.n > self.load_factor * self.size:
            self._resize()

    def discard(self, element: Any): #Discard method that takes an element as input and removes it from the hash table if it is present. This function first calculates the index of the bucket using the hash function. If the element is in the bucket it is removed and the number of elements is decreased
        i = self.hash_function(element)
        bucket = self.table[i]
        if element in bucket:
            bucket.remove(element)
            self.n -= 1

    def _resize(self): #Resizes the hash table and creates a new empty table and iterates over the old tables buckets and elements, calculates the hash code of each element, inserts the elements into the new table at the appropriate index replace the old table with the new table.
        self.size *= 2
        self.mask = self.size - 1
        new_table = [[] for _ in range(self.size)]
        for bucket in self.table:
            for element in bucket:
                i = self.hash_function(element)
                new_table[i].append(element)
        self.table = new_table

    def __iter__(self):
        for bucket in self.table:
            for element in bucket:
                yield element

class LinearSet(MySet):
    '''Overrides and implementes the methods defined in MySet. Uses a linear
    probing hash table to implement the set.
    '''
    def __init__(self, elements: [Any]) -> None:
        self.del_obj = "del" # Special object used to mark a deleted element in the hash table
        self.d = 1 # Parameter used to determine when to resize the hash table
        self.t = [None] * (2 ** self.d) # The hash table initialized as a list of None values
        self.q = 0 # Number of non-deleted elements currently stored in the hash table
        self.n = 0 # Total number of elements (including deleted elements) stored in the hash table
        for element in elements:  # Adding each element in the input list to the hash table
            self.add(element)

    def hash_function(self, x): #Used the built in hash function.
        return hash(x) % len(self.t)
    
    def find(self, x):
        i = self.hash_function(x)
        while self.t[i] is not None: #Continues to search for the element using linear probing until an empty or deleted bucket is found
            if self.t[i] is not self.del_obj and x == self.t[i]:
                return self.t[i] # If the current bucket contains the element it returns it
            i = (i + 1) % len(self.t) # If the current bucket contains a different element or a deleted element moves to the next bucket
        return None
    
    def add(self, element: Any):
        if self.find(element) is not None:
            return False
        if 2 * (self.q + 1) > len(self.t): # If the hash table is more than half full, resizes it to twice the current size
            self.resize()
        i = self.hash_function(element) # Gets the hash value of the element and starts searching for an empty bucket using linear probing
        while self.t[i] is not None and self.t[i] is not self.del_obj: # If an empty bucket is found, adds the element to it and updates the size and count variables
            i = (i + 1) % len(self.t)
        if self.t[i] is None:
            self.q += 1
        self.n += 1
        self.t[i] = element
        return True 
    
    def discard(self, element: Any):#Method used to remove an element from the hash table Gets the hash value of the element and starts searching for it from the corresponding bucket index
        i = self.hash_function(element)
        while self.t[i] is not None:
            y = self.t[i]
            if y is not self.del_obj and element == y:
                self.t[i] = self.del_obj
                self.n -= 1
                if 8 * self.n < len(self.t):
                    self.resize()
                return y
            i = (i + 1) % len(self.t)
        return None
    
    def resize(self):
        self.d = 1
        while 2 ** self.d < 3 * self.n:
            self.d += 1
        told = self.t
        self.t = [None] * (2 ** self.d)
        self.q = self.n #Update q and reinsert all elements from the old list into the new list
        for x in told:
            if x is not None and x is not self.del_obj: # Calculate the hash of each element and insert it into the new list
                i = self.hash_function(x)
                while self.t[i] is not None:
                    i = (i + 1) % len(self.t)
                self.t[i] = x

    def __iter__(self) -> Any:
        for key in self.t:
            if key != "del" and key != None:
                yield key 
    

class MyDict(object):
    '''An abstract class that provides a dictionary interface which is just
    sufficient for the implementation of this assignment.
    '''

    def __init__(self) -> None:
        """Initializes this dictionary.

        Args:
        - self: manadatory reference to this object.

        Returns:
        none
        """
        pass
    
    def __setitem__(self, key: Any, newvalue: Any) -> None:
        """Adds (key, newvalue) to the dictionary, overwriting any prior value.

        dunder method allows assignment using indexing syntax, e.g.
        d[key] = newvalue

        key must be hashable by pytohn.
        
        Args:
        - self: manadatory reference to this object.
        - key: the key to add to the dictionary
        - newvalue: the value to store for the key, overwriting any prior value 

        Returns:
        None
        """
        pass
    
    def get(self, key: Any, default: Any = None) -> Any:
        """Returns the value stored for key, default if no value exists.

        key must be hashable by pytohn.
        
        Args:
        - self: manadatory reference to this object.
        - key: the key whose value is sought.
        - default: the value to return if key does not exist in this dictionary

        Returns:
        the stored value for key, default if no such value exists.
        """
        pass

    def items(self) -> [(Any, Any)]:
        """Returns the key-value pairs of the dictionary as tuples in a list.
        
        Args:
        - self: manadatory reference to this object.

        Returns:
        the key-value pairs of the dictionary as tuples in a list.
        """
        pass

    def clear(self) -> None:
        """Clears the dictionary.

        Args:
        - self: manadatory reference to this object.

        Returns:
        None.
        """
        pass

class ChainedDict(MyDict):
    '''Overrides and implementes the methods defined in MyDict. Uses a chained
    hash table to implement the dictionary.
    '''
    def __init__(self, size=100):
        self.size = size # Initializing a chained hash table of the given size, 100 in our case
        self.table = [[] for _ in range(self.size)] # Initializing an empty list for each bucket in the hash table
        self.z = random.randrange(1, 2**32, 2) # Generating a random odd number z that will be used in the hash function
        self.n = 0 # Initializing the number of elements to 0
        
    def hash_function(self, key): #Hash function taken from the book
        return ((self.z * hash(key)) % 2**32) % self.size
    
    def __setitem__(self, key, newvalue):
        i = self.hash_function(key)
        for j, (k, v) in enumerate(self.table[i]): #If the key is already present in the hash table, update its value
            if k == key:
                self.table[i][j] = (key, newvalue)
                return
        self.table[i].append((key, newvalue))  #If the key does not exist, appending a new (key,value) pair to the corresponding bucket in the hash table.
        self.n += 1
        if self.n > 3 * self.size: #If the number of (key,value) pairs in the hash table exceeds 3 times the size, resize the hash table.
            self._resize()
    
    def get(self, key, default=None):
        i = self.hash_function(key) #Overriding the get method of MyDict to return the value of the given key or a default value if the key is not present in the hash table.
        for k, v in self.table[i]:
            if k == key:
                return v
        return default
    
    def items(self):
        result = []
        for bucket in self.table:
            for key, value in bucket:
                result.append((key, value))
        return result
    
    def clear(self):
        self.table = [[] for _ in range(self.size)]
        self.n = 0

    def _resize(self): #resizes the hash table and creates a new empty table and iterates over the old table's buckets and elements, computes the hash code of each element, inserts the elements into the new table at the appropriate index, and replaces the old table with the new table. Elements here mean (key,value) pairs
        self.size *= 2
        new_t = [[] for i in range(self.size)]
        self.n = 0
        for bucket in self.table:
            for key, value in bucket:
                new_t[self.hash_function(key)].append((key, value))
                self.n += 1
        self.table = new_t


class LinearDict(MyDict):
    '''Overrides and implementes the methods defined in MyDict. Uses a linear
    probing hash table to implement the dictionary.
    '''
    def __init__(self) -> None:
        self.size = 8 #Initializing the size of the hash table to 8
        self.del_obj = "del" # Special object used to mark a deleted element in the hash table
        self.d = 3 #A check for maintainign the number of probes
        self.t = [(None, None)] * self.size # The hash table initialized as a list of None (key,value) elements
        self.q = 0  #Number of non-deleted elements currently stored in the hash table
        self.n = 0 #Total number of elements (including deleted elements) stored in the hash table

    def hash_function(self, x):#Used to built in hash function.
        return hash(x) % len(self.t)
    
    def find(self, key):
        i = self.hash_function(key)
        while self.t[i][0] is not None:
            if self.t[i][0] is not self.del_obj and key == self.t[i][0]:
                return i #If the key is found and is not deleted, return its index.
            i = (i + 1) % len(self.t) #If the index is not empty, or contains a deleted key, check the next index using linear probing.
        return i
    
    def add(self, key: Any, value: Any):
        i = self.find(key)
        if self.t[i][0] == key:
            self.t[i] = (key, value)
            return False
        if 2 * (self.q + 1) > len(self.t): #If the hash table is more than half full, resizes it to twice the current size
            self.resize()
        i = self.find(key) #Finding the index where the key can be added, and add the key-value pair.
        if self.t[i][0] == key:
            self.t[i] = (key, value)
            return False
        if self.t[i][0] is None:
            self.q += 1
        self.n += 1
        self.t[i] = (key, value)
        return True 
    
    def __setitem__(self, key: Any, value: Any) -> None:
        self.add(key, value)
    
    def get(self, key: Any, default: Any = None) -> Any: #Gtting the value associated with a key
        i = self.find(key)
        if self.t[i][0] is None:
            return default
        return self.t[i][1]
    
    def items(self) -> [(Any, Any)]:
        result = []
        for key, value in self.t:
            if key is not None and key is not self.del_obj:
                result.append((key, value))
        return result
    
    def clear(self) -> None:
        self.size = 8
        self.d = 3
        self.t = [(None, None)] * self.size
        self.q = 0
        self.n = 0
        
    def resize(self):
        self.d += 1
        self.size = 2 ** self.d
        told = self.t
        self.t = [(None, None)] * self.size
        self.q = self.n = 0  #Updating q and reinserting all elements from the old list into the new list
        for key, value in told:
            if key is not None and key is not self.del_obj: # Calculating the hash of each element and insert it into the new list
                self.add(key, value)
    
    def __iter__(self) -> Any:
        for key in self.t:
            if key != "del" and key != None:
                yield key


  

