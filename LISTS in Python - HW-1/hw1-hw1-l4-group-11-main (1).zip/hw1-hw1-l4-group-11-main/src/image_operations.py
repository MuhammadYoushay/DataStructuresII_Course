from src.myimage import MyImage

def remove_channel(src: MyImage, red: bool = False, green: bool = False,
                   blue: bool = False) -> MyImage:
    """Returns a copy of src in which the indicated channels are suppressed.

    Suppresses the red channel if no channel is indicated. src is not modified.

    Args:
    - src: the image whose copy the indicated channels have to be suppressed.
    - red: suppress the red channel if this is True.
    - green: suppress the green channel if this is True.
    - blue: suppress the blue channel if this is True. 

    Returns:
    a copy of src with the indicated channels suppressed.
    """

    # creating an object copy of src object of myimage class
    new_image=MyImage(src.size)
    original_rows = src.size[1] #Original Rows of the Image Matrice
    original_columns = src.size[0] #Original Columns of the Image Matrice
    for i in range(original_columns):
        for j in range(original_columns):
            new_image.set(i,j,src.get(i,j)) #Setting the new image/copy image to the pixels of the original picture
    if red==True or (red==False and blue==False and green==False): #Condition to suppress Red
        for i in range(original_columns):
            for j in range(original_rows):
                temp_list = list(new_image.get(i,j))
                temp_list[0]=0
                tup = tuple(temp_list)
                new_image.set(i,j,tup)
    if green==True:#Condition to suppress Green
        for i in range(original_columns):
            for j in range(original_rows):
                temp_list = list(new_image.get(i,j))
                temp_list[1]=0
                tup = tuple(temp_list)
                new_image.set(i,j,tup)
    if blue==True:#Condition to suppress blue
        for i in range(original_columns):
            for j in range(original_rows):
                temp_list = list(new_image.get(i,j))
                temp_list[2]=0
                tup = tuple(temp_list)
                new_image.set(i,j,tup)
    return new_image



    

def rotations(src: MyImage) -> MyImage:
    """Returns an image containing the 4 rotations of src.

    The new image has twice the dimensions of src. src is not modified.

    Args:
    - src: the image whose rotations have to be stored and returned.

    Returns:
    an image twice the size of src and containing the 4 rotations of src.
    """
    temp=MyImage(src.size)
    temp = src

    obj1=MyImage(src.size)
    obj2=MyImage(src.size)
    obj3=MyImage(src.size)
    obj4=MyImage(src.size)

    t=MyImage((src.size[0]*2,src.size[1]*2)) #my image file with the rotated habib logos
    print (t.size)
 #RIGHT SIDE OF THE IMAGES COMBINED
    offsetr=0
    for x in range(2): #for 2 rotations of the logo
        row=obj1.size[1]-1
        print(offsetr+row)
        obj1=MyImage(src.size) #obj1 stores the first rotation
        for i in range (0,obj1.size[0]):#width =col
            col=0 
            for j in range (0,obj1.size[1]):#height=row
                var1=temp.get(j,i) #obj1 stores the first rotation and gets the relevant row and column of the integer of matrix
                obj1.set(row,col,var1) #obj1 stores the first rotation and sets the relevant row and column of the integer (transposed)
                t.set(offsetr+row,col,var1) #stores obj1 in the bigger image with the relevant row and fixed column(top leftmost)
                col+=1
            row-=1
        print(offsetr+row)
        temp=obj1   
        offsetr+=src.size[1] #incremnts so that now next row but same column logo
 #RIGHT SIDE OF THE IMAGES COMBINED
    offsetr=src.size[0]
    offsetc=src.size[1] #now we need to inc the col along with the column for the left side
    for x in range(2):
        row=obj1.size[1]-1
        print(offsetr+row)
        obj1=MyImage(src.size)
        for i in range (0,obj1.size[0]):#width =col
            col=0 
            for j in range (0,obj1.size[1]):#height=row
                var1=temp.get(j,i) #obj1 stores the first rotation and gets the relevant row and column of the integer of matrix
                obj1.set(row,col,var1) #obj1 stores the first rotation and sets the relevant row and column of the integer (transposed)
                t.set(offsetr+row,offsetc+col,var1) #stores obj1 in the bigger image with the relevant row and relvant column)
                col+=1
            row-=1
        print(offsetr+row)
        temp=obj1   
        offsetr=0
    return t





def apply_mask(src: MyImage, maskfile: str, average: bool = True) -> MyImage:
    """Returns an copy of src with the mask from maskfile applied to it.

    maskfile specifies a text file which contains an n by n mask. It has the
    following format:
    - the first line contains n
    - the next n^2 lines contain 1 element each of the flattened mask

    Args:
    - src: the image on which the mask is to be applied
    - maskfile: path to a file specifying the mask to be applied
    - average: if True, averaging should to done when applying the mask

    Returns:
    an image which the result of applying the specified mask to src.
   """
    new_image = MyImage(src.size) #Creating an object copy of src object of myimage class
    original_rows = src.size[1] #Original Rows of the Image Matrice
    original_columns = src.size[0] #Original Columns of the Image Matrice
    for i in range(original_rows):
        for j in range(original_columns):
            new_image.set(i,j,src.get(i,j)) #Setting the new image/copy image to the pixels of the original picture
    with open(maskfile, 'r') as file: #Reading the maskfile provided in the test case and storing the values in a list
        mask_size = int(file.readline().strip()) #The first line of the file tells us n - this is the size of the n x n mask
        mask_lst = [int(line.strip()) for line in file] #Storing rest of the elements of the file in form of a list
    for row in range(original_rows):#Loops to iterate through the image
        for col in range(original_columns):
            mask_value = 0 #Summation counter used in masking formulae  
            total_mask_weight = 0 #Summation counter used when average is True
            for i in range(mask_size ** 2): #Loop to iterate through the mask
                x = i//mask_size #Calculations to get to the neighbours by calculating quotient and remainder. Apply the given formulae for masking.
                y= i % mask_size
                row_mask = x - (mask_size // 2)
                col_mask = y - (mask_size // 2)
                if (0 <= row + row_mask < original_rows) and (0 <= col + col_mask < original_columns): #Checking for bounds
                    weight = mask_lst[i]
                    total_mask_weight = total_mask_weight + weight #Summing the total mask weight for cases where we have to get avg
                    pix = src.get(row + row_mask, col + col_mask)
                    mask_value = mask_value + (sum(pix) // 3) * weight #Averaging the rgb values and multiplying by the mask value at the ith position
            if average: #Condition if average is true
                mask_value = mask_value // total_mask_weight
            mask_value = min(255, max(0, mask_value)) #Setting minimum pixels to zero and maximum to 255 so that it remains within the rgb range
            new_image.set(row, col, (mask_value, mask_value, mask_value)) # Storing the new pixel 
    return new_image

def resize(src: MyImage) -> MyImage:
    """Returns an image which has twice the dimensions of src.

    The new image has twice the dimensions of src. src is not modified.

    Args:
    - src: the image which needs to be resized. 

    Returns:
    an image twice the size of src.
    """   

    original_rows = src.size[1] #No of Rows in the Orginal matrice
    original_columns = src.size[0] #No of columns in the Original matrice
    new_rows = original_rows * 2 #No of Rows we want in the new matrice
    new_columns = original_columns * 2 #No of columns we want in the new matrice
    new_image = MyImage((new_columns,new_rows)) #Creating a new image with double the rows and double the columns of the original
    for i in range(new_columns): #Setting all the tuples in the new_image list to zero
        for j in range(new_rows):
            zero_tuple = (0,0,0)
            new_image.set(i, j, zero_tuple)
    for k in range(original_columns): #Condition to copy the pixels from the source/original picture to the new image pixel that we generated previously. These vslus will be copied to every alternate block of the new image as the dimensions have doubled
        for l in range(original_rows):
            even_rows = k * 2
            even_columns = l * 2
            original_pixel = src.get(k,l)
            new_image.set(even_rows,even_columns,original_pixel)
    for x in range(new_columns): #Conditions to fill the blocks in odd rows and even columns by comparing the top and bottom pixels filled in the previous condition by taking out the average
        for y in range(new_rows):
            if(x%2==1) and (y%2!=1) and (x!=new_columns-1) :
                upper_pixel = new_image.get(x-1, y)
                lower_pixel = new_image.get(x+1, y)
                averaged_tuple1 = ((upper_pixel[0] + lower_pixel[0])//2, (upper_pixel[1] + lower_pixel[1])//2, (upper_pixel[2] + lower_pixel[2]) // 2)
                new_image.set(x,y,averaged_tuple1)
            elif (y%2!=1) and (x==new_columns-1):#Dealing with the last most row where no down pixel exists to take out average
                upper_pixel1 = new_image.get(x-1, y)
                new_image.set(x,y,upper_pixel1)
    for m in range(new_columns): #Conditions to access even rows and compare the left and right pixels
        for n in range(new_rows):
            if m%2!=1: 
                if n%2==1:  
                    if n!=new_rows-1:
                        left_pixel = new_image.get(m, n-1)
                        right_pixel = new_image.get(m, n+1)
                        averaged_tuple = ((left_pixel[0] + right_pixel[0])//2, (left_pixel[1] + right_pixel[1])//2, (left_pixel[2] + right_pixel[2]) // 2)
                        new_image.set(m,n,averaged_tuple) 
                    else: #Dealing with the left most column where no right pixel exists
                        left_pixel1 = new_image.get(m, n-1)
                        new_image.set(m,n,left_pixel1)
    for a in range(new_columns): #Conditions to deal with center pixels where we have to take the average of 4 neighbouring pixels as well as dealing with the last most column and row to fill the remaining pixels
        for b in range(new_rows):
            if(a%2==1) and (b%2==1) and (a!=new_columns-1) and (b!=new_rows-1):
                upper_left_pixel = new_image.get(a-1, b-1)
                upper_right_pixel = new_image.get(a-1, b+1)
                lower_left_pixel = new_image.get(a+1, b-1)
                lower_right_pixel = new_image.get(a+1, b+1) 
                averaged_tuple2 = ((upper_left_pixel[0] + upper_right_pixel[0] + lower_left_pixel[0] + lower_right_pixel[0])//4, (upper_left_pixel[1] + upper_right_pixel[1] + lower_left_pixel[1] + lower_right_pixel[1])//4, (upper_left_pixel[2] + upper_right_pixel[2] + lower_left_pixel[2] + lower_right_pixel[2])//4)
                new_image.set(a,b,averaged_tuple2)
            elif  (a==new_columns-1) and (b==new_rows-1):
                new_image.set(a,b,new_image.get(a-1,b-1))
            elif (a%2!=0) and (a!=new_columns-1) and (b==new_rows-1):
                new_image.set(a,b,new_image.get(a,b-1))
            elif (b%2!=0) and (a==new_columns-1) and (b!=new_rows-1):
                new_image.set(a,b,new_image.get(a-1,b))
    return new_image



