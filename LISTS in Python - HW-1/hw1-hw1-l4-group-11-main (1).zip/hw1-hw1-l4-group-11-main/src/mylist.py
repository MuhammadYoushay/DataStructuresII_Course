from numpy import size
import array

class MyList:
    '''A list interface. Also implements Iterator functions in order to support
    iteration over this list.
    '''

    def __init__(self, size: int, value=None) -> None:
        """Creates a list of the given size, optionally intializing elements to value.

        The list is static. It only has space for size elements.

        Parameters:
        - self: mandatory reference to this object
        - size: size of the list; space is reserved for these many elements.
        - value: the optional initial value of the created elements.

        Returns:
        none
        """
        pass


    def __len__(self) -> int:
        '''Returns the size of the list. Allows len() to be called on it.

        Ref: https://stackoverflow.com/q/7642434/1382487

        Parameters:
        - self: mandatory reference to this object

        Returns:
        the size of the list.
        '''
        pass 

    def __getitem__(self, i: int):
        '''Returns the value at index, i. Allows indexing syntax.

        Ref: https://stackoverflow.com/a/33882066/1382487

        Parameters:
        - self: mandatory reference to this object
        - i: the index from which to retrieve the value.

        Returns:
        the value at index i.
        '''
        # Ensure bounds.
        assert 0 <= i < len(self),\
            f'Getting invalid list index {i} from list of size {len(self)}'
        pass

    def __setitem__(self, i: int, value) -> None:
        '''Sets the element at index, i, to value. Allows indexing syntax.

        Ref: https://stackoverflow.com/a/33882066/1382487

        Parameters:
        - self: mandatory reference to this object
        - i: the index of the elemnent to be set
        - value: the value to be set

        Returns:
        none
        '''
        # Ensure bounds.
        assert 0 <= i < len(self),\
            f'Setting invalid list index {i} in list of size {len(self)}'
        pass

    def __iter__(self) -> 'MyList':
        '''Iterator function to return an iterator (self) that allows iteration over
        this list.

        Parameters:
        - self: mandatory reference to this object

        Returns:
        an iterator (self) that allows iteration over this list.
        '''
        # Initialize iteration index.
        self._iter_index: int = 0
        return self

    def __next__(self):
        ''''Iterator function to return the next value from this list.

        Parameters:
        - self: mandatory reference to this object

        Returns:
        the next value in this list since the last iteration.
        '''
        if self._iter_index < len(self):
            value = self.get(self._iter_index)
            self._iter_index += 1
            return value
        else:
            # End of Iteration
            self._index = 0
            raise StopIteration

    def get(self, i: int):
        '''Returns the value at index, i.

        Alternate to use of indexing syntax.

        Parameters:
        - self: mandatory reference to this object
        - i: the index from which to retrieve the value.

        Returns:
        the value at index i.
        '''
        return self[i]

    def set(self, i: int, value) -> None:
        '''Sets the element at index, i, to value.

        Alternate to use of indexing syntax.

        Parameters:
        - self: mandatory reference to this object
        - i: the index of the elemnent to be set
        - value: the value to be set

        Returns:
        none
        '''
        self[i] = value


class ArrayList(MyList):
    
    def __init__(self, size: int, value=None) -> None:
        self.size=size
        self.array1=array.array("i",[0]*size)
        self.red=array.array("i",[value[0]]*size) #value is the tuple with red at 0 index which we have multiplied by the size (l*w) in the same format mentioned in myimage.py 
        self.green=array.array("i",[value[1]]*size) #value is the tuple with green at 1 index which we have multiplied by the size (l*w) in the same format mentioned in myimage.py
        self.blue=array.array("i",[value[2]]*size) #value is the tuple with blue at 2 index which we have multiplied by the size (l*w) in the same format mentioned in myimage.py
        for i in range(self.size):
            self.array1[i]=i 

    def __len__(self) -> int:
        return self.size #have to check

    def __getitem__(self, i: int):
        return (self.red[i],self.green[i],self.blue[i]) # will return a tuple at i (pixel) 

    def __setitem__(self, i: int, value) -> None:
        self.red[i]=value[0]
        self.green[i]=value[1]
        self.blue[i]=value[2]
    


















    



    




