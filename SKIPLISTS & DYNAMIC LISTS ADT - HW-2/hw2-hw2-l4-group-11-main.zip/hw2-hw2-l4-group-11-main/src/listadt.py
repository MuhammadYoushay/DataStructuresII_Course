import array
class DynamicArrayList: #Dynamic Array List Class

    def __init__(self):
        self.sizee = 1 #Initializing the size of the array
        self.counterr = 0 #Counter for the number of elements in the array
        initialize = [-1] * self.sizee #Used for array creation
        self.array = array.array("i", initialize)  #Creating the array

    def insert(self, index, value): #Function to insert a value at a specific index in the list
        if self.counterr == self.sizee: #Check if the list is full
            self.sizee=self.sizee*2 #Double the array size
            initialize = [-1] * self.sizee
            new_array = array.array("i", initialize) #Initialize the doubled size array 
            for i in range(self.counterr):
                new_array[i] = self.array[i] #Copying elements from the old array to the new one
            self.array = new_array #Making the old array equal to the new resized array which now also has the elements
        i = index #Inserting in the array
        while i < self.counterr:
            self.array[i + 1] = self.array[i] #Creating space between two elements so that our value can be inserted at the specific key
            i = i + 1
        self.array[index] = value
        self.counterr = self.counterr + 1 #Incrementing the number of elements counterr in the list

    def delete(self, index): #Function for deletion at a specific index
        x = index
        while x < self.counterr - 1: #Incrementing through the array only at the indexes where an element is counterr
            self.array[x] = self.array[x+1] #Removing the element at that index by making the value at that index equal to the value in front of it
            x = x + 1
        self.counterr = self.counterr - 1 #Decrementing the number of elements present in the array 
        y = self.counterr
        while y < self.sizee: #Now that elements have shifted left after removal, initializing the remaining elements with our initialized value of -1
            self.array[y] = -1
            y = y + 1
        if self.counterr <= self.sizee // 4: #If the array has become quarter the original size, resizing it to half like we did above when we doubled it
            self.sizee = self.sizee // 2
            initialize = [-1] * self.sizee
            new_array = array.array("i", initialize)
            for i in range(self.counterr):
                new_array[i] = self.array[i]
            self.array = new_array

    def display(self): 
        return(list(self.array))
    
    def size(self):
        return self.counterr
    
    def get(self,index):
        if index < 0 or index >= self.counterr:
            return None
        return self.array[index]
    
# //////////////////////////////////////////.....////////////////////////////////////////////////////////////

#Linked list class implementation 


class Node: #Node Class

    def __init__(self, data = None):
        self.data = data #Holds the value
        self.next = None #Holds the next node
        
class LinkedList:

    def __init__(self):
        self.head = None #Making a HEAD of the list 
        
    def insert(self, index, value):
        new_node = Node(value) #Making a node which holds the inserted value as data
        if index == 0: #If the insertion index is zero then chaning the head and adjusting accordingly
            new_node.next = self.head
            self.head = new_node
        else:
            current = self.head #Making a temporary node to iterate over the list
            for i in range(index - 1):
                if current == None:
                    break
                current = current.next #Looping through the list until reaching the index counterr before the required index
            if current != None: #Making sure that we have not reached the end of the list or are at the start
                new_node.next = current.next
                current.next = new_node
        
    def delete(self, index):
        if index == 0: #Condition is we want to delete the head - we'll have to make the next node our new head
            if self.head != None:
                self.head = self.head.next
                return
            else:
                return
        current = self.head
        counter = 0
        while counter < index - 1 and current != None: #Looping through the list until the index before deletion index is found
            current = current.next
            counter = counter + 1
        current.next = current.next.next #Skiping the middle node between current.next and cureent.next.next hence removing it from our link

    def get(self, index): #Simply looping and getting to the index
        current = self.head
        for i in range(index):
            if current != None:
                current = current.next
            else:
                break
        return current.data
    def display(self): #Creating a list to maintain the traversal
        lst = []
        temp = self.head
        while temp !=None:
            lst.append(temp.data)
            temp = temp.next
        return lst
    def size(self): #Running a counter to get the size
        size = 0
        current = self.head
        while current!=None:
            size = size + 1
            current = current.next
        return size
    
def load(file_path, out_file):
    """
    Loads and performs the operations specified in the input file on either a dynamic array list or a linked list.
    
    :param file_path: the path of the input file
    :type file_path: str
    :param out_file: the name of the output file
    :type out_file: str
    """
    with open(file_path, 'r') as file:
        data_structure = file.readline().strip()
        operations = file.readlines()
        out = []
        if data_structure == "array":
            ds = DynamicArrayList()
        else:
            ds = LinkedList()
        for op in operations:
            op = op.strip().split()
            if op[0] == "insert":
                ds.insert(int(op[1]),int(op[2]))
            elif op[0] == "delete":
                ds.delete(int(op[1]))
            elif op[0] == "get":
                out.append(ds.get(int(op[1])))
            elif op[0] == "size":
                out.append(ds.size())
            elif op[0] == "display":
                out.append(ds.display())
        with open(out_file, 'w') as f:
            for item in out:
                f.write("%s\n" % item)
#load("./data/input1.txt","temp.txt")
# load("../data/input1.txt","tmp-out1.txt")
# load("../data/input3.txt","tmp-out2.txt")
