
import random
import sys
from typing import Any, Optional


class Node(object):
    '''A node in a skiplist. It stores a (key, value) pair along with pointers
    for each level in its tower.

    The key is used to compare nodes. The tower automatically includes level 0.
    '''
    
    def __init__(self, data: (Any,Any), height: int=0) -> None:
        '''Construct node with given data and of given height.

        The height is the largest level, begining from 0, of the tower.

        Parameters:
        - self: mandatory reference to this object
        - data: the (key, value) pair to store in this node
        - height: the number of levels in the tower (excludes level 0)

        Returns:
        None
        '''
        # initializing the pointers as implementation of skiplist has been made through linkedlist
        self.up=None
        self.down=None
        self.right=None
        self.left=None
        self.heightx=height
        #data=((key,value),height)
        self.value=data[1]
        self.key=data[0]  
        self.bound=None 
    
    def __repr__(self) -> str:
        '''Returns the representation of this node.

        Implement any representation that helps you debug.

        Parameters:
        - self: mandatory reference to this object

        Returns:
        this node's string representation.
        '''
        a=str(self.value)+str(self.key)+" is the value , key of the node with level " +str(self.heightx)
        return a 

    def __str__(self) -> str:
        '''Returns a string representation of this node.

        See the link below for the difference between the __repr__ and __str__
        methods: https://www.geeksforgeeks.org/str-vs-repr-in-python/

        Parameters:
        - self: mandatory reference to this object

        Returns:
        this node's string representation.
        '''
        return self.__repr__()
    
    def height(self) -> int:
        '''Returns the height of this node's tower.

        The height is the largest level, begining from 0, of the tower.

        Parameters:
        - self: mandatory reference to this object

        Returns:
        the height of this node's tower.
        '''
        return self.height # returns the height of the skiplist

    def key(self) -> Any:
        '''Returns the key stored in this node.

        Parameters:
        - self: mandatory reference to this object

        Returns:
        the key stored in this node.
        '''
        return self.key

    def value(self) -> Any:
        '''Returns the value stored in this node.

        Parameters:
        - self: mandatory reference to this object

        Returns:
        the value stored in this node.
        '''
        return self.value

    def add_level(self, forward: Optional[Any] = None) -> None:
        '''Adds a level to this node which points to forward.

        Parameters:
        - self: mandatory reference to this object
        - forward: the node that this node will point to in the new level.

        Returns:
        None.
        '''
        self.up=forward
        forward.down=self # making up and down pinters for the node 

neg_infinity = ("*", 0) # left sentinel check

class SkipList(object):
    '''A skiplist of nodes containing (key, value) pairs. Nodes are ordered
    according to keys. Keys are unique, reinserting an existing key overwrites
    the value.

    The skiplist contains a sentinel node by default and the height of the
    sentinel node is the height of the list.
    '''

    def __init__(self) -> None:
        '''Construct empty skiplist.
        Parameters:
        - self: mandatory reference to this object
        Returns:
        None
        '''
        self.Node1 = Node(neg_infinity, 0) # negative inifinity
        self.head =  self.Node1
        self.level = 0
        
    def __len__(self) -> int:
        '''Returns the number of pairs stored in this skiplist.

        dunder method allows calling len() on this object.

        Parameters:
        - self: mandatory reference to this object

        Returns:
        the number of pairs stored in this skiplist.
        '''
        count=0
        level_p=self.head
        counter=self.h
        while(counter>=0): #counter is for the levels
            temp=level_p
            while (temp!=None): #it is for traversing within the specific level
                temp=temp.right
                count+=1
            if level_p.down!=None:  #reaching a level down and updating the down pointer
                level_p=level_p.down
            counter-=1
        return count #returns the length of the skiplist

    def __repr__(self) -> str:
        '''Returns a string representation of this skiplist.

        Implement any representation that helps you debug.

        Parameters:
        - self: mandatory reference to this object

        Returns:
        this skiplist's string representation.
        '''
        upd=self.head

        counter=upd.h
        y=""
        while(counter>=0):
            temp = upd
            while (temp!=None): 
                y+=str(temp.value)+ " , " +str(temp.h)+ " . "
                temp=temp.right #updating the right pointer
            y+="\n"
            upd=upd.down #updating the down pointer in order to demonstrate the skiplist structure
            
            counter-=1
        return y 

    def __str__(self) -> str:
        '''Returns a string representation of this skiplist.

        See the link below for the difference between the __repr__ and __str__
        methods: https://www.geeksforgeeks.org/str-vs-repr-in-python/

        Parameters:
        - self: mandatory reference to this object

        Returns:
        this skiplist's string representation.
        '''
        return self.__repr__()

    def _search_path(self, key: Any) -> [Node]:
        '''Returns the search path in this skiplist for key.

        The search path contains one node for each level of the skiplist
        begining from the highest and ending at level 0. The node for each
        level is the one corresponding to a descend in the search path.

        Parameters:
        - self: mandatory reference to this object
        - key: the key being searched for

        Returns:
        the descend nodes at each level of the skiplist, ordered from highest
        level to level 0.
        '''
        lst=[]
        temp=self.head
        counter=self.level
        lst.append(temp) #appending head for the first node pointed 
        while(counter>=0 ): #for levels
            begin=temp.right
            while (begin!=None): #for finding the key               
                if (begin.key<=key):
                    begin=begin.right #updating the right pointer of the node in the center
                    temp=temp.right #updating the right pointer of the node from which we begined
                    lst.append(temp)
                    if temp.key==key:
                            return lst #returning the path stored in the list if we get the searching key succesfully
                else:                   
                    break
            counter-=1
            if counter!=-1: #decreasing level
                temp=temp.down #updating down pointer
                lst.append(temp)
        return lst

    def _find_prev(self, key: Any) -> Node:
        '''Returns the node in the skiplist that contains the predecessor key.

        Parameters:
        - self: mandatory reference to this object
        - key: the key being searched for

        Returns:
        the node in the skiplist that contains the predecessor key.
        '''
        temp=self.head
        output=None
        counter=self.level
        while(counter>=0): #for levels
            begin=temp.right
            while (begin!=None):                
                if (begin.key<=key):#for the key
                    begin=begin.right 
                    temp=temp.right
                    # if temp.key==key:
                    #     output=temp.value
                    counter=0
                else:                   
                    break
            counter-=1
            if counter!=-1:
                temp=temp.down
        return output.left #returning the previous key stored in skiplist
      
        
    def reset(self) -> None:
        '''Empty the skiplist.

        Parameters:
        - self: mandatory reference to this object

        Returns:
        None
        '''
        reset1=self.head
        while (reset1.down!=None):
            reset1=reset1.down
        reset1.left==None #reaching the floor level we just rset or delete  left,right up and down pointers of the node
        reset1.right==None
        reset1.down==None
        reset1.up==None
       
    def height(self) -> int:
        '''Returns the height of the skiplist.

        The height is the largest level of the sentinel's tower.

        Parameters:
        - self: mandatory reference to this object

        Returns:
        the height of this skiplist.
        '''
        return self.level #returns the height of the skiplist

    def find(self, key: Any) -> Optional[Any]:
        '''Returns the value stored in this skiplist corresponding to key, None
        if key does not exist in this skiplist.

        Parameters:
        - self: mandatory reference to this object
        - key: the key whose value is sought

        Returns:
        the stored value for key, None if key does not exist in this skiplist.
        '''
       
        temp=self.head
        output=None
        counter=self.level
        while(counter>=0): #for the levels
            begin=temp.right
            while (begin!=None):                
                if (begin.key<=key): #for the specific key searching whcih has a corresponding value to look up in the datafile
                    begin=begin.right 
                    temp=temp.right
                    if temp.key==key:
                        output=temp.value
                        return output #finds out that key
                else:
                    
                    break
            counter-=1
            if counter!=-1:
                temp=temp.down
         
    def find_range(self, key1: Any, key2: Any) -> [Any]:
        '''Returns the values stored in this skiplist corresponding to the keys
        between key1 and key2 inclusive in sorted order of keys.

        Parameters:
        - self: mandatory reference to this object
        - key1: begining key in the range of keys whose value is sought
        - key2: ending key in the range of keys whose value is sought

        Returns:
        the stored values for the keys between key1 and key2 inclusive in sorted
        order of keys.
        '''
        temp=self.head
        output=None
        counter=self.level
        final=[]
        while(counter>=0):
            begin=temp.right
            while (begin!=None):                
                if (begin.key<=key1):
                    begin=begin.right 
                    temp=temp.right #seraching for a key within a level and then appending side by side in the list so that we get the range of the keys from strating from key1 till key2
                    if temp.key==key1:
                        output=temp.value
                else:
                    break
            counter-=1
            if counter!=-1:
                temp=temp.down
        
        while (temp!=None):
            final.append(temp.value)
            temp=temp.right
            if temp.key==key2:
                final.append(temp.value)
                return final #it appends the all the records in the order of the keys in the range

    def remove(self, key: Any) -> Optional[Any]:
        '''Returns the value stored for key in this skiplist and removes
        (key, value) from this skiplist, returns None if key is not stored in
        this skiplist.

        Parameters:
        - self: mandatory reference to this object
        - key: the key to be removed

        Returns:
        the stored value for key in this skiplist, None if key does not exist
        in this skiplist
        '''
        temp=self.head
        output=None
        counter=self.level
        while(counter>=0):
            begin=temp.right
            while (begin!=None):                
                if (begin.key<=key):
                    begin=begin.right 
                    temp=temp.right
                    if temp.key==key:
                        output=temp.value
                        counter=0
                else:                   
                    break
            counter-=1
            if counter!=-1:
                temp=temp.down
        if output==None:
            return output #this is all same as of looking up or finding the key

        else:
            while(temp!=None):
                temp.left.right=temp.right #updating the pointers and removing the key 
                if temp.right!=None:
                    temp.right.left=temp.left
                temp=temp.down
            return output 

    def insert(self, data: (Any,Any)) -> None:
            '''Inserts a (key value) pair in this skiplist, overwrites the old value
            if key already exists.
            Parameters:
            - self: mandatory reference to this object
            - data: the (key, value) pair
            Returns:
            None
            '''
            
            
            lst1 = self._search_path(data[0])
            pop_node = lst1.pop() # to get the last node in our search path

            # checking to see if the key already exists or not and updating
            if pop_node.key == data[0] and   pop_node.value == data[1] and pop_node != None:
                    pop_node.value = data[1]
                    pop_node = pop_node.down
                    return
            begin = pop_node
            if self.is_empty()==False:  #Checking if the list is initially empty              
                new_data = Node(data, 0)
                new_data.left = pop_node 
                new_data.right = pop_node.right
                pop_node.right = new_data
            else:
                new_data = Node(data, 0) # setting the same data with height of 0
                new_data.right = begin.right
                new_data.left = begin
                new_data.bound = self.Node1 # setting the lefftmost value of the new node
                begin.right = new_data
                if pop_node.key == neg_infinity[0]:
                    new_data.bound = pop_node # for if the pop_node is actually the bound itself
                else:
                    new_data.bound = pop_node.bound

            while random.randint(1,2)!=1: #Random leveles condition
                while pop_node.up == None and len(lst1) != 0: #Checing the left most element
                    pop_node = lst1.pop()
                if pop_node.heightx == self.level:  #if condition to check if we have to add the height or not
                    temp = Node((new_data.key, new_data.value),self.level + 1)  #Temporary node made
                    temp_left = Node(neg_infinity, self.level + 1) # negative inifinity
                    temp.left = temp_left #left node of the new height node
                    temp_left.right = temp #link between the boundary with the node
                    temp.bound = temp_left #left boundary
                    pop_node.add_level(temp.bound)
                    new_data.add_level(temp)
                    pop_node = temp.bound 
                    new_data = temp
                    self.head= temp_left #reaasigning the head to the top height of the skip list
                    self.level += 1 
                else:  # for adding the elements in a pre-existent height
                    pop_node = pop_node.up
                    inc_level = Node((new_data.key, new_data.value), pop_node.heightx)
                    inc_level.right = pop_node.right
                    pop_node.right = inc_level
                    inc_level.left = pop_node
                    inc_level.bound = new_data.bound
                    new_data.add_level(inc_level)
                    new_data = inc_level
                    pop_node = lst1.pop() # current pointer's value has been changed, the pointer is changed to the next pop value



               

    def size(self) -> int:
        '''Returns the number of pairs stored in this skiplist.

        Parameters:
        - self: mandatory reference to this object

        Returns:
        the number of pairs stored in this skiplist.
        '''
        return self.__len__() 
    
    def is_empty(self) -> bool:
        '''Returns whether the skiplist is empty.

        Parameters:
        - self: mandatory reference to this object

        Returns:
        True if no pairs are stored in this skiplist, False otherwise.
        '''
        if (self.head==self.Node1) and (self.head.right==None) :
            return True
        else:
            return False #checking if key , values present then retuen false



