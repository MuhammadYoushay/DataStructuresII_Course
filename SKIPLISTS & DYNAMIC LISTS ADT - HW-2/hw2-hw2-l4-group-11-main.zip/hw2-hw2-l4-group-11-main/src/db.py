from typing import List, Optional
from src.skiplist import SkipList
import csv

class Table(object):
    '''A table that stores records and allows creation of an index on the
    records according to the values of a specified attribute. The index is used
    to efficiently retrieve records using key values. The index can be
    re-initialized in run-time using a different attribute.
    '''
    
    def __init__(self) -> None:
        '''Initialize this table with an empty index.

        The index is initialized with an empty skiplist.

        Parameters:
        - self: mandatory reference to this object

        Returns:
        None
        '''
        self.skplist=SkipList()
        
    def read(self, csvfile: str) -> None:
        '''Read and store records from the given CSV file.

        Parameters:
        - self: mandatory reference to this object
        - csvfile: path to a csv file that contains the records

        Returns:
        None
        '''
        self.novels = []
        with open(csvfile, 'r', encoding='utf-8') as file:
            csvreader = csv.reader(file)
            for row in csvreader:
                self.novels.append(row)
        print(len(self.novels))

    def create_index(self, attribute: str) -> None:
        '''Construct an index using values of the specified attribute.

        attribute must be one of the column headers from the CSV file from which
        the records were read. all values for attribute must be unique.

        Any existing index is lost and a new one is constructed. The constructed
        index is empty if no records are currently stored.

        The index stores (key, value) pairs where the keys are the values of
        attribute. The value is the location, e.g. index, of the corresponding
        record. Note that the value is not the record itself.

        Parameters:
        - self: mandatory reference to this object
        - attribute: the attribute whose values are to be the keys in the index

        Returns:
        None
        '''
        self.skplist=SkipList()
        num=self.novels[0].index(attribute) #specifying the attribute index
        for x in range(1,len(self.novels)):
            self.skplist.insert((self.novels[x][num],x)) #this tuple has a((key,value),postion) so that we can insert at the relevant place

    def select(self, key: str) -> Optional[List[str]]:
        '''Return the record corresponding to the given key, None in case of
        error.

        The index is used to find the record. An error occurs if the index is
        not yet created or the key in invalid. This is indicated by a return of
        None.

        Parameters:
        - self: mandatory reference to this object
        - key: the key whose corresponding value is sought

        Returns:
        The record corresponding to key, None in case of error.
        '''
        if (self.skplist.find(key)!=None):
            return self.novels[(self.skplist.find(key))] #It simply calls through find function inorder to find the key if it is present
        else:
            return None

    def select_range(self, start: str, end: str) -> Optional[List[List[str]]]:
        '''Returns the records corresponding to the keys in the range
        [start,end] inclusive, None in case of error.

        An error occurs if no index has been created, start or end is not a valid
        key in the index, or start is not less than end.

        Parameters:
        - self: mandatory reference to this object
        - start: the starting key value in the range of keys
        - end: the ending key value in the range of keys

        Returns:
        The records in the order of the keys in the range [start,end], None in
        case of error.
        '''
        if start>end:
            return None # it determines that if the starting key is greater then none
        elif self.skplist.find(start)==None or self.skplist.find(end)==None:
            return None  #if start and end arent present that means the rage of keys doesnt exist
        elif start==end:
            return self.novels[self.skplist.find(start)] #if single key is there or start and end are same
        else:
            final=[]
            a=self.skplist.find_range(start,end)
            for i in a:
                final.append(self.novels[i]) #it appends the all the records in the order of the keys in the range
        return final

    def delete(self, key: str) -> Optional[List[str]]:
        '''Deletes the record corresponding to key from the table and the index.
        Returns the deleted record, None in case of error.

        An error occurs if no index has been created, or key does not exist in
        it.

        Parameters:
        - self: mandatory reference to this object
        - from: the starting key value in the range of keys
        - to: the ending key value in the range of keys

        Returns:
        The deleted record,  None in case of error.
        '''
        if self.skplist.remove(key)==None:
            return None
        else:
            return self.novels[(self.skplist.remove(key))] #removes the key and the corresponding record if it is present
        

        
        
